﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.WindowsAPICodePack.Dialogs;
using System.Xml;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.Linq.Expressions;


namespace CodeReviewerUI
{
    public partial class FormCodeReviewer : Form
    {
        System.Data.DataTable dt = new System.Data.DataTable();
        int Coun = 0;
        
        string savepath = @"C:\Users\" + Environment.UserName + @"\Documents\CodeReviewResult.xls";

        public FormCodeReviewer()
        {
            InitializeComponent();
            
        }

    
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                lstbox_ProjectName.Items.Clear();
                CommonOpenFileDialog dialog = new CommonOpenFileDialog();
                dialog.IsFolderPicker = true;
                if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
                {
                    txtBrowse.Text = dialog.FileName;

                    DirectoryInfo directory = new DirectoryInfo(dialog.FileName);
                    DirectoryInfo[] directories = directory.GetDirectories();

                    for (int i = 0; i <= directories.Length - 1; i++)
                    {
                        if (!directories[i].ToString().ToLower().ToLower().ToLower().Contains("vs") && !directories[i].ToString().ToLower().Contains("git") && !directories[i].ToString().Contains("bin") && !directories[i].ToString().ToLower().Contains("obj") && !directories[i].ToString().ToLower().Contains("properties"))
                        {
                            lstbox_ProjectName.Items.Add(directories[i].ToString());
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void FormCodeReviewer_Load(object sender, EventArgs e)
        {
            try
            {
                foreach (string process in Properties.Settings.Default.ProcessName)
                {
                    cmbbox_ProcessName.Items.Add(process);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
            
        }

        private void btnAnalyzecode_Click(object sender, EventArgs e)
        {
            try
            {
                

                if (cmbbox_ProcessName.Text.ToString().Trim() == string.Empty)
                {
                    MessageBox.Show("Please Select Process Name from the Dropdown menu");
                }
                else if (txtBrowse.Text.ToString().Trim() == string.Empty)
                {
                    MessageBox.Show("Please Browse and Select Folder Path");
                }
                else
                {
                    string Category = "";
                    string Description = "";
                    string impact = "";
                    string AutomationName = "";
                    string filetyp = "";
                    bool Enexflagvar = false;
                    bool runloaderflag = false;
                    //File size

                    var files = System.IO.Directory.GetFiles(txtBrowse.Text, "*.*", System.IO.SearchOption.AllDirectories);
                    
                    foreach (string file in files)
                    {
                        if (file.Contains("Events"))
                        {
                            bool autxflag = false;
                            foreach (string item in lstbox_ProjectName.Items)
                            {
                                if ((Path.GetFileName(file).Contains(item) && Path.GetFileName(file).Contains("_E")) || (Path.GetFileName(file).Contains("Main") && Path.GetFileName(file).Contains("_E")))
                                {
                                    //GC is as per naming convention

                                }
                                else
                                {
                                    autxflag = true;
                                }
                            }
                            if (autxflag == true)
                            {
                                AutomationName = Path.GetFileName(file);
                                impact = "High";
                                filetyp = "Automation";
                                Description = "Automation In Events Should contain Project_E_Eventname or Main_E_EventName";
                                Category = "Naming Convention";
                                Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);

                            }
                            autxflag = false;
                        }
                        if (file.Contains("Procedures"))
                        {
                            bool autxflag = false;
                            foreach (string item in lstbox_ProjectName.Items)
                            {
                                if ((Path.GetFileName(file).Contains(item) && Path.GetFileName(file).Contains("_P")) || (Path.GetFileName(file).Contains("Main") && Path.GetFileName(file).Contains("_P")))
                                {
                                    //GC is as per naming convention

                                }
                                else
                                {
                                    autxflag = true;
                                }

                            }

                            if (autxflag == true)
                            {
                                AutomationName = Path.GetFileName(file);
                                impact = "High";
                                filetyp = "Automation";
                                Description = "Automation In Procedure Should contain Project_P_Eventname or Main_P_EventName";
                                Category = "Naming Convention";
                                Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);

                            }
                            autxflag = false;
                        }
                        if (file.EndsWith(".os"))
                        {
                            XmlDocument gxDoc = new XmlDocument();

                            //load up the xml from the location 
                            gxDoc.Load(file);
                            string gtag = "ComponentInfo";
                            XmlNodeList nodes = gxDoc.GetElementsByTagName(gtag);
                            foreach (XmlNode gnode in nodes)
                            {
                                if (gnode.Name == "ComponentInfo")
                                {

                                    string gcontent = gnode.InnerXml;

                                    //Web Adapter
                                    Adapter_check(gcontent, "WebAdp_", "OpenSpan.Adapters.Web.WebAdapter", file, gxDoc, AutomationName, impact, filetyp, Description, Category);
                                    //Universal Web Adapter
                                    Adapter_check(gcontent, "UWebAdp_", "OpenSpan.Adapters.Web.Universal.UniversalWebAdapter", file, gxDoc, AutomationName, impact, filetyp, Description, Category);
                                    //Windows Adapter
                                    Adapter_check(gcontent, "WinAdp_", "OpenSpan.Adapters.Windows.WindowsAdapter", file, gxDoc, AutomationName, impact, filetyp, Description, Category);

                                    long filesize = new System.IO.FileInfo(file).Length;
                                    var size = Int64.Parse(filesize.ToString());
                                    if (size > 200000)
                                    {
                                        AutomationName = Path.GetFileName(file);
                                        impact = "Low";
                                        filetyp = "Automation";
                                        Description = "File size is greater than 200KB";
                                        Category = "Maintainability";
                                        Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                                        //MessageBox.Show("Automation Name: " + AutomationName);
                                        //MessageBox.Show("Description: " + Description);
                                        //MessageBox.Show("Category: "+ Category);
                                        //MessageBox.Show("Impact: " + impact);

                                    }

                                    /****************************GC Naming Convention And Variables Check************************************/
                                    //GC Naming Convention
                                    if (gcontent.Contains("OpenSpan.Automation.GlobalContainer"))
                                    {
                                        bool gcflag = false;
                                        foreach (string item in lstbox_ProjectName.Items)
                                        {
                                            if (Path.GetFileName(file).Contains(item) && Path.GetFileName(file).Contains("_GC"))
                                            {
                                                //GC is as per naming convention

                                            }
                                            else
                                            {
                                                gcflag = true;
                                            }
                                        }
                                        if (gcflag == true)
                                        {
                                            AutomationName = Path.GetFileName(file);
                                            impact = "High";
                                            filetyp = "GC";
                                            Description = "Rename GC to proper naminig convention as ApplicationName_GC";
                                            Category = "Naming Convention";
                                            Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);

                                        }
                                        gcflag = false;
                                    }
                                    //GC variable validation
                                    //string check
                                    Autx_GC_variablescheck(gcontent, "OpenSpan.Automation.GlobalContainer", "Pega.Controls.Variables.StringVariable", "str_", file, AutomationName, impact, filetyp, Description, Category, "variable");
                                    //int check
                                    Autx_GC_variablescheck(gcontent, "OpenSpan.Automation.GlobalContainer", "Pega.Controls.Variables.IntegerVariable", "int_", file, AutomationName, impact, filetyp, Description, Category, "variable");
                                    //bool check
                                    Autx_GC_variablescheck(gcontent, "OpenSpan.Automation.GlobalContainer", "Pega.Controls.Variables.BooleanVariable", "bool_", file, AutomationName, impact, filetyp, Description, Category, "variable");
                                    //double check
                                    Autx_GC_variablescheck(gcontent, "OpenSpan.Automation.GlobalContainer", "Pega.Controls.Variables.DoubleVariable", "dbl_", file, AutomationName, impact, filetyp, Description, Category, "variable");
                                    //decimal check
                                    Autx_GC_variablescheck(gcontent, "OpenSpan.Automation.GlobalContainer", "Pega.Controls.Variables.DecimalVariable", "dml_", file, AutomationName, impact, filetyp, Description, Category, "variable");
                                    //datetime check
                                    Autx_GC_variablescheck(gcontent, "OpenSpan.Automation.GlobalContainer", "Pega.Controls.Variables.DateTimeVariable", "dtm_", file, AutomationName, impact, filetyp, Description, Category, "variable");
                                    //character check
                                    Autx_GC_variablescheck(gcontent, "OpenSpan.Automation.GlobalContainer", "Pega.Controls.Variables.CharVariable", "chr_", file, AutomationName, impact, filetyp, Description, Category, "variable");


                                    //Script check
                                    Autx_GC_variablescheck(gcontent, "OpenSpan.Automation.GlobalContainer", "OpenSpan.Script.Custom.Script", "scr_", file, AutomationName, impact, filetyp, Description, Category, "Script");


                                    

                                    /**********************************Project Naming Convention Check***************************/


                                    XmlDocument xDoc = new XmlDocument();

                                    //load up the xml from the location 
                                    xDoc.Load(file);
                                    string tag = "Comments";
                                    XmlNodeList nodesC = xDoc.GetElementsByTagName(tag);
                                    foreach (XmlNode node in nodesC)
                                    {
                                        if (node.Name == "Comments")
                                        {

                                            string content = node.InnerXml;
                                            if (content.Contains("Comment Text"))

                                            {
                                                //Comments exist
                                            }

                                            else
                                            {
                                                filetyp = "Automation";
                                                AutomationName = Path.GetFileName(file);
                                                impact = "Low";
                                                Description = "Comment is missing in Automation";
                                                Category = "Best Practice";
                                                Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                                                //MessageBox.Show("Automation Name: " + AutomationName);
                                                //MessageBox.Show("Description: " + Description);
                                                //MessageBox.Show("Category: " + Category);
                                                //MessageBox.Show("Impact: " + impact);


                                            }


                                        }
                                    }



                                    //variables in Autx
                                    if (xDoc.InnerXml.Contains("OpenSpan.Automation.Automator"))
                                    {
                                        //string check
                                        Autx_variablescheck(xDoc, "Pega.Controls.Variables.StringVariable", "str_", file, AutomationName, impact, filetyp, Description, Category, "variable");

                                        //int check
                                        Autx_variablescheck(xDoc, "Pega.Controls.Variables.IntegerVariable", "int_", file, AutomationName, impact, filetyp, Description, Category, "variable");
                                        //bool check
                                        Autx_variablescheck(xDoc, "Pega.Controls.Variables.BooleanVariable", "bool_", file, AutomationName, impact, filetyp, Description, Category, "variable");

                                        //double check
                                        Autx_variablescheck(xDoc, "Pega.Controls.Variables.DoubleVariable", "dbl_", file, AutomationName, impact, filetyp, Description, Category, "variable");

                                        //decimal check
                                        Autx_variablescheck(xDoc, "Pega.Controls.Variables.DecimalVariable", "dml_", file, AutomationName, impact, filetyp, Description, Category, "variable");

                                        //datetime check
                                        Autx_variablescheck(xDoc, "Pega.Controls.Variables.DateTimeVariable", "dtm_", file, AutomationName, impact, filetyp, Description, Category, "variable");

                                        //character check
                                        Autx_variablescheck(xDoc, "Pega.Controls.Variables.CharVariable", "chr_", file, AutomationName, impact, filetyp, Description, Category, "variable");


                                        //script check
                                        Autx_variablescheck(xDoc, "OpenSpan.Script.Custom.Script", "scr_", file, AutomationName, impact, filetyp, Description, Category, "script");
                                    }

                                    //Asynchronous check
                                    
                                    string tagA = "AutomationDocument";
                                    XmlNodeList nodesA = xDoc.GetElementsByTagName(tagA);
                                    foreach (XmlNode node in nodesA)
                                    {

                                        if (node.InnerXml.Contains("RuntimeLoader.AllProjectsStarted"))
                                        {
                                            runloaderflag = true;
                                            if (node.InnerXml.Contains("Asynchronous=\"True"))

                                            {
                                                //Event Link is Asynchronous
                                            }

                                            else
                                            {

                                                AutomationName = Path.GetFileName(file);
                                                filetyp = "Automation";
                                                impact = "High";
                                                Description = "Event link Runtime All Projects started must be Asynchronous ";
                                                Category = "Best Practice";
                                                Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                                                //MessageBox.Show("Automation Name: " + AutomationName);
                                                //MessageBox.Show("Description: " + Description);
                                                //MessageBox.Show("Category: " + Category);
                                                //MessageBox.Show("Impact: " + impact);

                                            }
                                        }
                                        
                                       

                                    }


                                    //EntryExitPoint check
                                    if (xDoc.InnerXml.Contains("OpenSpan.Automation.Automator"))
                                    {
                                        Enexflagvar = Autx_EntryExitcheck(xDoc, "OpenSpan.Automation.EntryPoint", "ENTP_", file, AutomationName, impact, filetyp, Description, Category, "script", Enexflagvar, runloaderflag);

                                        Enexflagvar = Autx_EntryExitcheck(xDoc, "OpenSpan.Automation.ExitPoint", "EXTP_", file, AutomationName, impact, filetyp, Description, Category, "script", Enexflagvar, runloaderflag);

                                    }

                                    //suppress errors check

                                    string tags = "OpenSpan.Automation.Automator";
                                    XmlNodeList nodess = xDoc.GetElementsByTagName(tags);
                                    foreach (XmlNode node in nodess)
                                    {

                                        
                                        if (node.OuterXml.ToLower().Contains("suppresserrors"))

                                        {
                                            //Event Link is Asynchronous
                                        }

                                        else
                                        {

                                            AutomationName = Path.GetFileName(file);
                                            filetyp = "Automation";
                                            impact = "High";
                                            Description = "Suppress Errors should be set to True in Automation Property";
                                            Category = "Automation Property";
                                            Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);

                                        }
                                        

                                    }

                                    


                                    foreach (XmlNode node in nodesA)
                                    {


                                        if (node.InnerXml.Contains("DisplayName Value=\"TRY") && node.InnerXml.Contains("DisplayName Value=\"CATCH"))
                                        {
                                            //Automation has Try catch block
                                        }

                                        else
                                        {
                                            AutomationName = Path.GetFileName(file);
                                            impact = "High";
                                            filetyp = "Automation";
                                            Description = "Try..Catch Block is missing in the Automation";
                                            Category = "Exception Handling";
                                            Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);

                                            //MessageBox.Show("Automation Name: " + AutomationName);
                                            //MessageBox.Show("Description: " + Description);
                                            //MessageBox.Show("Category: " + Category);
                                            //MessageBox.Show("Impact: " + impact);

                                        }

                                    }


                                }
                            }
                        }
                        else if (file.EndsWith(".ossln"))
                        {
                            if (file.Contains(cmbbox_ProcessName.Text.ToString().Trim()))
                            {
                                //solution file has correct naming convention
                            }
                            else
                            {
                                AutomationName = Path.GetFileName(file);
                                impact = "High";
                                filetyp = "OSSLN";
                                Description = "Solution File should be in correct naming convention " + cmbbox_ProcessName.Text + ".ossl";
                                Category = "Naming Convention";
                                Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                            }
                        }
                        else if (file.EndsWith(".osproj"))
                        {
                            bool Projectnameflag = false;
                            foreach (string item in lstbox_ProjectName.Items)
                            {
                                if (Path.GetFileName(file).Contains(item))
                                {
                                    // Project Name is in correct format
                                    Projectnameflag = true;
                                }

                            }

                            if (Projectnameflag == true)
                            {
                                // Project Name is in correct format
                            }
                            else
                            {
                                AutomationName = Path.GetFileName(file);
                                impact = "Low";
                                filetyp = "OSPROJ";
                                Description = "Project Name is not as Per the Naming convention- FolderName.osproj";
                                Category = "Naming Convention";
                                Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                            }

                            Projectnameflag = false;
                        }

                    }

                    
                  
                    
                    MessageBox.Show("Code Analysis Completed Successfully. Please Generate Report to see the results");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());            }
            
        }

        public void Autx_variablescheck(XmlDocument xDoc, string tagva, string variable, string file, string AutomationName, string impact, string filetyp, string Description, string Category,string datatype)
        {
            try
            {
                string tagvar = tagva;
                XmlNodeList nodesvar = xDoc.GetElementsByTagName(tagvar);

                foreach (XmlNode node in nodesvar)
                {


                    if (node.OuterXml.ToLower().Contains(variable))

                    {
                        //Event Link is Asynchronous
                    }

                    else
                    {

                        AutomationName = Path.GetFileName(file);
                        filetyp = "Automation";
                        impact = "High";
       
                        Description = node.Attributes["Name"].Value + " " + datatype + " should be starting with " + variable;
                        Category = "Naming Convention";
                       
                        Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                        //MessageBox.Show("Automation Name: " + AutomationName);
                        //MessageBox.Show("Description: " + Description);
                        //MessageBox.Show("Category: " + Category);
                        //MessageBox.Show("Impact: " + impact);

                    }


                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public bool Autx_EntryExitcheck(XmlDocument xDoc, string tagva, string variable, string file, string AutomationName, string impact, string filetyp, string Description, string Category, string datatype,bool Enexflag,bool runloaderflag)
        {
            
            try
            {
                string tagvar = tagva;
                XmlNodeList nodesvar = xDoc.GetElementsByTagName(tagvar);
                
                foreach (XmlNode node in nodesvar)
                {
                    Enexflag = true;

                    if (node.OuterXml.ToLower().Contains(variable))

                    {
                        //Entry/Exitpoint Exist
                    }

                    

                }
                if (Enexflag == false)
                {
                    if (runloaderflag == true)
                    {
                    // Start point of autx entry exit point not required
                    }
                    else
                    {
                        AutomationName = Path.GetFileName(file);
                        filetyp = "Automation";
                        impact = "High";
                        if (tagva == "OpenSpan.Automation.EntryPoint")
                        {
                            Description = "Entry Point Missing in the Automation";
                        }
                        else if (tagva == "OpenSpan.Automation.ExitPoint")
                        {
                            Description = "Exit Point Missing in the Automation";
                        }

                        Category = "Best Practice";

                        Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return Enexflag;
        }


        public void Autx_GC_variablescheck(string gcontent, string comparenode,string variable, string gctagvar, string file,string AutomationName,string impact,string filetyp,string Description,string Category,string datatype)
        {
            try
            {
                if (gcontent.Contains(comparenode))
                {


                    XmlDocument gcDoc = new XmlDocument();
                    gcDoc.Load(file);
                    string gctag = gctagvar;
                    XmlNodeList gcnodes = gcDoc.GetElementsByTagName(gctag);

                    foreach (XmlNode gcnode in gcnodes)
                    {
                        string gccontent = gcnode.OuterXml;
                        if (gccontent.ToLower().Contains(variable))

                        {
                            //String naming convention is correct
                        }
                        else
                        {

                            AutomationName = Path.GetFileName(file);
                            impact = "High";
                            filetyp = "GC";
                            Description = gcnode.Attributes["Name"].Value + " " + datatype + " should be starting with " + variable;
                            Category = "Naming Convention";
                            Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                            //MessageBox.Show("Automation Name: " + AutomationName);
                            //MessageBox.Show("Description: " + Description);
                            //MessageBox.Show("Category: " + Category);
                            //MessageBox.Show("Impact: " + impact);
                            //MessageBox.Show("Filetype: " + filetyp);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void Adapter_check(string gcontent,string adapterprefix,string Adapter,string file, XmlDocument gxDoc,string AutomationName,string impact,string filetyp,string Description,string Category)
        {
            try
            {
                if (gcontent.Contains(Adapter))

                {
                    XmlDocument webxDoc = new XmlDocument();
                    webxDoc.Load(file);
                    string webtag = Adapter;
                    XmlNodeList webnodes = gxDoc.GetElementsByTagName(webtag);

                    bool webadapnameflag = false;
                    foreach (string item in lstbox_ProjectName.Items)
                    {
                        if (!Path.GetFileName(file).StartsWith(adapterprefix) && !Path.GetFileName(file).Contains(item))
                        {
                            // Web adapter incorect is in correct format
                            webadapnameflag = true;
                        }

                    }

                    if (webadapnameflag == true)
                    {
                        // Web adapter incorect
                        AutomationName = Path.GetFileName(file);
                        impact = "High";
                        filetyp = "Adapter";
                        Description = "Adapter Name " + Path.GetFileName(file) + " is not as Per the Naming convention - Kindly Mention as " + adapterprefix + " ApplicationName";
                        Category = "Naming Convention";
                        Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                    }

                    foreach (XmlNode webnode in webnodes)
                    {

                        if (webnode.Name == Adapter)
                        {

                            string webcontent = webnode.InnerXml;
                            if (webcontent.Contains("StartOnProjectStart Value=\"False"))

                            {
                                //StartOnProjectStart is set to False
                            }

                            else
                            {

                                AutomationName = Path.GetFileName(file);
                                impact = "High";
                                filetyp = "Adapter";
                                Description = "StartOnProjectStart must be False";
                                Category = "Maintainability";
                                Writevaluetodatatable(AutomationName, filetyp, Description, Category, impact);
                                //MessageBox.Show("Automation Name: " + AutomationName);
                                //MessageBox.Show("Description: " + Description);
                                //MessageBox.Show("Category: " + Category);
                                //MessageBox.Show("Impact: " + impact);
                                //MessageBox.Show("Filetype: " + filetyp);

                            }
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        

        public System.Data.DataTable Report()
        {
            
                System.Data.DataTable dt = new System.Data.DataTable();
                dt.Columns.Add("FileName");
                dt.Columns.Add("FileType");
                dt.Columns.Add("Description");
                dt.Columns.Add("Category");
                dt.Columns.Add("Impact");   
           
            

            return dt;
        }
        public System.Data.DataTable Writevaluetodatatable(string AutomationName, string filetyp, string Description, string Category, string impact)
        {
            try
            {
                if (Coun == 0)
                {

                    dt.Columns.Add("FileName");
                    dt.Columns.Add("FileType");
                    dt.Columns.Add("Description");
                    dt.Columns.Add("Category");
                    dt.Columns.Add("Impact");
                    DataRow dr = dt.NewRow();
                    dr["FileName"] = AutomationName;
                    dr["FileType"] = filetyp;
                    dr["Description"] = Description;
                    dr["Category"] = Category;
                    dr["Impact"] = impact;
                    dt.Rows.Add(dr);
                    Coun++;
                    


                }
                else
                {
                    DataRow dr = dt.NewRow();
                    dr["FileName"] = AutomationName;
                    dr["FileType"] = filetyp;
                    dr["Description"] = Description;
                    dr["Category"] = Category;
                    dr["Impact"] = impact;
                    dt.Rows.Add(dr);
                   

                }
                return dt;
            }
            //System.Data.DataTable dt = new System.Data.DataTable();

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                
                return dt;
               
            }
        }

        public void btnGenerateReport_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (File.Exists(savepath))
                {
                    File.Delete(savepath);
                }
                System.Data.DataTable uniqueCols = dt.DefaultView.ToTable(true);
                for (int i = uniqueCols.Rows.Count - 1; i >= 0; i--)
                {
                    if (uniqueCols.Rows[i]["Description"].ToString().Trim() == string.Empty)
                    {
                        uniqueCols.Rows.RemoveAt(i);
                    }
                    
                }
                GenerateReport(uniqueCols);
                int highcount = 0;
                int medcount = 0;
                int lowcount = 0;
                var high = uniqueCols.AsEnumerable().Where(x => x.Field<string>("Impact").Equals("High"));
                if (!high.Any())
                {
                    highcount = 0;
                }
                else
                {
                    System.Data.DataTable highdt = high.CopyToDataTable();
                    highcount = highdt.Rows.Count;
                }
                var medium = uniqueCols.AsEnumerable().Where(x => x.Field<string>("Impact").Equals("Medium"));
                if (!medium.Any())
                {
                    medcount = 0;
                }
                else
                {
                    System.Data.DataTable mediumdt = medium.CopyToDataTable();
                    medcount = mediumdt.Rows.Count;
                }
               
                var low = uniqueCols.AsEnumerable().Where(x => x.Field<string>("Impact").Equals("Low"));
                if (!low.Any())
                {
                    lowcount = 0;
                }
                else
                {
                    System.Data.DataTable lowdt = low.CopyToDataTable();
                    lowcount = lowdt.Rows.Count;
                }
                
                
                if (highcount >= Convert.ToInt32(Properties.Settings.Default.MaxThreshold))
                {
                    rdBad.Checked = true;
                    rdHigh.Checked = true;
                }
                else if (medcount >= Convert.ToInt32(Properties.Settings.Default.MediumThreshold))
                {
                    rdAverage.Checked = true;
                    rdmedium.Checked = true;
                }
                else if (lowcount > Convert.ToInt32(Properties.Settings.Default.LowMaxThreshold))
                {
                    rdAverage.Checked = true;
                    rdmedium.Checked = true;
                }
                else if (lowcount >= Convert.ToInt32(Properties.Settings.Default.LowMinThreshold) && lowcount <= Convert.ToInt32(Properties.Settings.Default.LowMaxThreshold))
                {
                    rdGood.Checked = true;
                    rdLow.Checked = true;
                }
                else if (lowcount <= Convert.ToInt32(Properties.Settings.Default.LowMinThreshold))
                {
                    rdGood.Checked = true;
                    rdNone.Checked = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void GenerateReport(System.Data.DataTable dt)
        {
            try
            {
                Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                if (xlApp == null)
                {
                    MessageBox.Show("Excel is not properly installed");
                    //return;
                }


                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);


                //int lastRow = xlWorkSheet.Cells.SpecialCells(XlCellType.xlCellTypeLastCell, Type.Missing).Row + 1;

                
                StreamWriter wr = new StreamWriter(savepath);
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    wr.Write(dt.Columns[i].ToString().ToUpper() + "\t");
                }

                wr.WriteLine();

                //write rows to excel file
                for (int i = 0; i < (dt.Rows.Count); i++)
                {
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        if (dt.Rows[i][j] != null)
                        {
                            wr.Write(Convert.ToString(dt.Rows[i][j]) + "\t");
                        }
                        else
                        {
                            wr.Write("\t");
                        }
                    }
                    //go to next line
                    wr.WriteLine();
                }
                //close file
                wr.Flush();
                wr.Close();
                wr.Dispose();
                //File.Move(savepath, Path.ChangeExtension(savepath, ".xlsx"));

                //xlWorkBook.SaveAs(savepath, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();


                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlApp);

                MessageBox.Show("Report Generated,you can find the file in " + savepath);
            }
            //System.Data.DataTable dt = Writevaluetodatatable();
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
           
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            cmbbox_ProcessName.SelectedIndex = 0;
            txtBrowse.Text = string.Empty;
            lstbox_ProjectName.Items.Clear();
            rdLow.Checked = false;
            rdmedium.Checked = false;
            rdHigh.Checked = false;
            rdNone.Checked = false;
            rdGood.Checked = false;
            rdAverage.Checked = false;
            rdBad.Checked = false;
            if (File.Exists(savepath))
            {
                File.Delete(savepath);
            }
            dt.Clear();
        }
    }
}
