﻿
namespace CodeReviewerUI
{
    partial class FormCodeReviewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCodeReviewer));
            this.lblfolderpath = new System.Windows.Forms.Label();
            this.txtBrowse = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnAnalyzecode = new System.Windows.Forms.Button();
            this.btnGenerateReport = new System.Windows.Forms.Button();
            this.lblCodeReviewer = new System.Windows.Forms.Label();
            this.lblstrength = new System.Windows.Forms.Label();
            this.lblImpact = new System.Windows.Forms.Label();
            this.rdGood = new System.Windows.Forms.RadioButton();
            this.rdAverage = new System.Windows.Forms.RadioButton();
            this.rdBad = new System.Windows.Forms.RadioButton();
            this.rdLow = new System.Windows.Forms.RadioButton();
            this.rdmedium = new System.Windows.Forms.RadioButton();
            this.rdHigh = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbbox_ProcessName = new System.Windows.Forms.ComboBox();
            this.lstbox_ProjectName = new System.Windows.Forms.ListBox();
            this.rdNone = new System.Windows.Forms.RadioButton();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblfolderpath
            // 
            this.lblfolderpath.AutoSize = true;
            this.lblfolderpath.BackColor = System.Drawing.Color.Black;
            this.lblfolderpath.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfolderpath.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblfolderpath.Location = new System.Drawing.Point(64, 170);
            this.lblfolderpath.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblfolderpath.Name = "lblfolderpath";
            this.lblfolderpath.Size = new System.Drawing.Size(142, 17);
            this.lblfolderpath.TabIndex = 0;
            this.lblfolderpath.Text = "Select Folder Path";
            // 
            // txtBrowse
            // 
            this.txtBrowse.Location = new System.Drawing.Point(278, 170);
            this.txtBrowse.Margin = new System.Windows.Forms.Padding(4);
            this.txtBrowse.Name = "txtBrowse";
            this.txtBrowse.Size = new System.Drawing.Size(510, 23);
            this.txtBrowse.TabIndex = 1;
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.DimGray;
            this.btnBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnBrowse.Location = new System.Drawing.Point(810, 154);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(4);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(118, 55);
            this.btnBrowse.TabIndex = 2;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnAnalyzecode
            // 
            this.btnAnalyzecode.BackColor = System.Drawing.Color.DimGray;
            this.btnAnalyzecode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnalyzecode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAnalyzecode.Location = new System.Drawing.Point(123, 354);
            this.btnAnalyzecode.Margin = new System.Windows.Forms.Padding(4);
            this.btnAnalyzecode.Name = "btnAnalyzecode";
            this.btnAnalyzecode.Size = new System.Drawing.Size(198, 60);
            this.btnAnalyzecode.TabIndex = 4;
            this.btnAnalyzecode.Text = "Analyze Code";
            this.btnAnalyzecode.UseVisualStyleBackColor = false;
            this.btnAnalyzecode.Click += new System.EventHandler(this.btnAnalyzecode_Click);
            // 
            // btnGenerateReport
            // 
            this.btnGenerateReport.BackColor = System.Drawing.Color.DimGray;
            this.btnGenerateReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerateReport.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnGenerateReport.Location = new System.Drawing.Point(419, 354);
            this.btnGenerateReport.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenerateReport.Name = "btnGenerateReport";
            this.btnGenerateReport.Size = new System.Drawing.Size(215, 60);
            this.btnGenerateReport.TabIndex = 5;
            this.btnGenerateReport.Text = "Generate Report";
            this.btnGenerateReport.UseVisualStyleBackColor = false;
            this.btnGenerateReport.Click += new System.EventHandler(this.btnGenerateReport_Click);
            // 
            // lblCodeReviewer
            // 
            this.lblCodeReviewer.AutoSize = true;
            this.lblCodeReviewer.Font = new System.Drawing.Font("Lucida Bright", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodeReviewer.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblCodeReviewer.Location = new System.Drawing.Point(430, 22);
            this.lblCodeReviewer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCodeReviewer.Name = "lblCodeReviewer";
            this.lblCodeReviewer.Size = new System.Drawing.Size(204, 22);
            this.lblCodeReviewer.TabIndex = 6;
            this.lblCodeReviewer.Text = "RPA Code Reviewer";
            this.lblCodeReviewer.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblstrength
            // 
            this.lblstrength.AutoSize = true;
            this.lblstrength.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblstrength.Location = new System.Drawing.Point(64, 458);
            this.lblstrength.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstrength.Name = "lblstrength";
            this.lblstrength.Size = new System.Drawing.Size(99, 17);
            this.lblstrength.TabIndex = 10;
            this.lblstrength.Text = "Code Strength";
            // 
            // lblImpact
            // 
            this.lblImpact.AutoSize = true;
            this.lblImpact.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImpact.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblImpact.Location = new System.Drawing.Point(64, 528);
            this.lblImpact.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblImpact.Name = "lblImpact";
            this.lblImpact.Size = new System.Drawing.Size(49, 17);
            this.lblImpact.TabIndex = 11;
            this.lblImpact.Text = "Impact";
            // 
            // rdGood
            // 
            this.rdGood.AutoCheck = false;
            this.rdGood.AutoSize = true;
            this.rdGood.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdGood.ForeColor = System.Drawing.Color.Green;
            this.rdGood.Location = new System.Drawing.Point(278, 454);
            this.rdGood.Margin = new System.Windows.Forms.Padding(4);
            this.rdGood.Name = "rdGood";
            this.rdGood.Size = new System.Drawing.Size(61, 21);
            this.rdGood.TabIndex = 12;
            this.rdGood.TabStop = true;
            this.rdGood.Text = "Good";
            this.rdGood.UseVisualStyleBackColor = true;
            // 
            // rdAverage
            // 
            this.rdAverage.AutoCheck = false;
            this.rdAverage.AutoSize = true;
            this.rdAverage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdAverage.ForeColor = System.Drawing.Color.DarkOrange;
            this.rdAverage.Location = new System.Drawing.Point(398, 454);
            this.rdAverage.Margin = new System.Windows.Forms.Padding(4);
            this.rdAverage.Name = "rdAverage";
            this.rdAverage.Size = new System.Drawing.Size(79, 21);
            this.rdAverage.TabIndex = 13;
            this.rdAverage.TabStop = true;
            this.rdAverage.Text = "Average";
            this.rdAverage.UseVisualStyleBackColor = true;
            // 
            // rdBad
            // 
            this.rdBad.AutoCheck = false;
            this.rdBad.AutoSize = true;
            this.rdBad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBad.ForeColor = System.Drawing.Color.Red;
            this.rdBad.Location = new System.Drawing.Point(545, 454);
            this.rdBad.Margin = new System.Windows.Forms.Padding(4);
            this.rdBad.Name = "rdBad";
            this.rdBad.Size = new System.Drawing.Size(166, 21);
            this.rdBad.TabIndex = 14;
            this.rdBad.TabStop = true;
            this.rdBad.Text = "Bad (Action Required)";
            this.rdBad.UseVisualStyleBackColor = true;
            // 
            // rdLow
            // 
            this.rdLow.AutoCheck = false;
            this.rdLow.AutoSize = true;
            this.rdLow.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdLow.ForeColor = System.Drawing.Color.Yellow;
            this.rdLow.Location = new System.Drawing.Point(402, 526);
            this.rdLow.Margin = new System.Windows.Forms.Padding(4);
            this.rdLow.Name = "rdLow";
            this.rdLow.Size = new System.Drawing.Size(51, 21);
            this.rdLow.TabIndex = 15;
            this.rdLow.TabStop = true;
            this.rdLow.Text = "Low";
            this.rdLow.UseVisualStyleBackColor = true;
            // 
            // rdmedium
            // 
            this.rdmedium.AutoCheck = false;
            this.rdmedium.AutoSize = true;
            this.rdmedium.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdmedium.ForeColor = System.Drawing.Color.DarkOrange;
            this.rdmedium.Location = new System.Drawing.Point(522, 526);
            this.rdmedium.Margin = new System.Windows.Forms.Padding(4);
            this.rdmedium.Name = "rdmedium";
            this.rdmedium.Size = new System.Drawing.Size(75, 21);
            this.rdmedium.TabIndex = 16;
            this.rdmedium.TabStop = true;
            this.rdmedium.Text = "Medium";
            this.rdmedium.UseVisualStyleBackColor = true;
            // 
            // rdHigh
            // 
            this.rdHigh.AutoCheck = false;
            this.rdHigh.AutoSize = true;
            this.rdHigh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdHigh.ForeColor = System.Drawing.Color.Red;
            this.rdHigh.Location = new System.Drawing.Point(669, 526);
            this.rdHigh.Margin = new System.Windows.Forms.Padding(4);
            this.rdHigh.Name = "rdHigh";
            this.rdHigh.Size = new System.Drawing.Size(170, 21);
            this.rdHigh.TabIndex = 17;
            this.rdHigh.TabStop = true;
            this.rdHigh.Text = "High (Action Required)";
            this.rdHigh.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(64, 107);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 17);
            this.label1.TabIndex = 18;
            this.label1.Text = "Process Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(64, 238);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "Project Name";
            // 
            // cmbbox_ProcessName
            // 
            this.cmbbox_ProcessName.FormattingEnabled = true;
            this.cmbbox_ProcessName.Location = new System.Drawing.Point(278, 107);
            this.cmbbox_ProcessName.Name = "cmbbox_ProcessName";
            this.cmbbox_ProcessName.Size = new System.Drawing.Size(244, 24);
            this.cmbbox_ProcessName.TabIndex = 21;
            // 
            // lstbox_ProjectName
            // 
            this.lstbox_ProjectName.FormattingEnabled = true;
            this.lstbox_ProjectName.ItemHeight = 16;
            this.lstbox_ProjectName.Location = new System.Drawing.Point(278, 211);
            this.lstbox_ProjectName.Name = "lstbox_ProjectName";
            this.lstbox_ProjectName.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.lstbox_ProjectName.Size = new System.Drawing.Size(246, 116);
            this.lstbox_ProjectName.TabIndex = 22;
            // 
            // rdNone
            // 
            this.rdNone.AutoCheck = false;
            this.rdNone.AutoSize = true;
            this.rdNone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdNone.ForeColor = System.Drawing.Color.Green;
            this.rdNone.Location = new System.Drawing.Point(278, 528);
            this.rdNone.Margin = new System.Windows.Forms.Padding(4);
            this.rdNone.Name = "rdNone";
            this.rdNone.Size = new System.Drawing.Size(60, 21);
            this.rdNone.TabIndex = 23;
            this.rdNone.TabStop = true;
            this.rdNone.Text = "None";
            this.rdNone.UseVisualStyleBackColor = true;
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.Color.DimGray;
            this.btn_Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Clear.Location = new System.Drawing.Point(735, 354);
            this.btn_Clear.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(215, 60);
            this.btn_Clear.TabIndex = 25;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = false;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(780, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(180, 73);
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // FormCodeReviewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(987, 600);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.rdNone);
            this.Controls.Add(this.lstbox_ProjectName);
            this.Controls.Add(this.cmbbox_ProcessName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rdHigh);
            this.Controls.Add(this.rdmedium);
            this.Controls.Add(this.rdLow);
            this.Controls.Add(this.rdBad);
            this.Controls.Add(this.rdAverage);
            this.Controls.Add(this.rdGood);
            this.Controls.Add(this.lblImpact);
            this.Controls.Add(this.lblstrength);
            this.Controls.Add(this.lblCodeReviewer);
            this.Controls.Add(this.btnGenerateReport);
            this.Controls.Add(this.btnAnalyzecode);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtBrowse);
            this.Controls.Add(this.lblfolderpath);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormCodeReviewer";
            this.Text = "Code Reviewer Tool";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Load += new System.EventHandler(this.FormCodeReviewer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblfolderpath;
        private System.Windows.Forms.TextBox txtBrowse;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnAnalyzecode;
        private System.Windows.Forms.Button btnGenerateReport;
        private System.Windows.Forms.Label lblCodeReviewer;
        private System.Windows.Forms.Label lblstrength;
        private System.Windows.Forms.Label lblImpact;
        private System.Windows.Forms.RadioButton rdGood;
        private System.Windows.Forms.RadioButton rdAverage;
        private System.Windows.Forms.RadioButton rdBad;
        private System.Windows.Forms.RadioButton rdLow;
        private System.Windows.Forms.RadioButton rdmedium;
        private System.Windows.Forms.RadioButton rdHigh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbbox_ProcessName;
        private System.Windows.Forms.ListBox lstbox_ProjectName;
        private System.Windows.Forms.RadioButton rdNone;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

